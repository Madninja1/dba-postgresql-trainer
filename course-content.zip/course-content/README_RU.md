# Структура учебного контента

[English version](README.md)

Учебный контент локализуется каталогами. У каждой логической темы может быть один или несколько языковых вариантов:

```text
course-content/
└── <course>/
    └── <topic>/
        ├── en/
        │   ├── topic.json
        │   └── questions.json
        └── ru/
            ├── topic.json
            └── questions.json
```

Языковой каталог может быть пустым. Пустые каталоги можно заранее сохранять в Git через `.gitkeep`: реестр контента игнорирует их, пока одновременно не появятся `topic.json` и `questions.json`.

## Коды курсов

Коды курсов не ограничены направлением DBA. Используется формат:

```text
<track>-<positive-number>
```

`track` начинается со строчной ASCII-буквы и может содержать строчные ASCII-буквы, цифры и одиночные дефисы. Примеры:

```text
dba-1
rust-1
sql-1
python-1
postgresql-dba-2
```

Последняя числовая часть должна быть больше нуля. Благодаря этому новые учебные направления можно добавлять без изменения схемы контента и прикладного кода.

## Порядок тем и принадлежность к конспектам

В каждом `topic.json` вместе с `sort_order` хранятся два числовых поля метаданных:

```json
{
  "notes_part": 3,
  "topic_number": 3,
  "sort_order": 30
}
```

- `notes_part` показывает, к какой части/файлу конспекта относится тема;
- `topic_number` — видимый пользователю номер темы внутри курса;
- `sort_order` остаётся техническим значением сортировки.

`notes_part` и `topic_number` должны быть больше нуля. `topic_number` должен быть уникальным внутри одного курса. Это логические метаданные темы, поэтому во всех locale-вариантах одной темы они должны совпадать.

Для текущего курса `rust-1` пятнадцать файлов конспекта соответствуют темам с номерами от `1` до `15` один к одному.

## Выбор контента по locale во время работы

Выбор локализованного учебного контента реализован и для Android, и для TUI.

При смене языка интерфейса тренажёр выбирает соответствующий языковой вариант каждой логической темы и синхронизирует его с уже существующими записями SQLite. Логические идентификаторы остаются прежними, поэтому смена языка сама по себе не сбрасывает сессии и статистику.

Для каждой темы используется следующий порядок выбора:

1. точное совпадение locale, например `en-us`;
2. базовый язык, например `en`;
3. резервный язык проекта `ru`;
4. первый доступный язык этой темы.

Поэтому текущий пустой каталог `en/` является корректным: английский UI будет использовать существующий русский банк вопросов до тех пор, пока кто-либо не добавит английский перевод.

Названия языковых каталогов должны быть записаны в нижнем регистре, например `en`, `ru`, `pt-br`.

## Совместимость переводов

Перевод — не отдельный независимый банк вопросов, а локализованное представление той же логической темы.

Для одной и той же `<course>/<topic>` во всех языках должны совпадать:

- `topic.course`;
- `topic.slug`;
- `topic.notes_part`;
- `topic.topic_number`;
- `topic.sort_order`;
- ключи вопросов;
- типы вопросов;
- ключи вариантов ответа;
- признак правильности вариантов ответа;
- ключи и типы источников.

Можно переводить:

- название и описание темы;
- текст вопроса;
- текст вариантов ответа;
- объяснение;
- текстовые поля module, section и locator источника;
- URL источника, если существует подходящая локализованная документация.

Встроенный загрузчик проверяет совместимость языковых вариантов до выбора locale. Если перевод изменяет логическую идентичность вопроса/ответа или правильность ответа, загрузка контента завершается ошибкой вместо скрытого повреждения семантики сессий и статистики.

## Текущий контент

Сейчас банк DBA-1 заполнен на русском языке и находится в `ru/`:

```text
course-content/
└── dba-1/
    └── 01-tools-install/
        ├── en/
        │   └── .gitkeep
        └── ru/
            ├── topic.json
            └── questions.json
```

Чтобы добавить перевод, достаточно положить соответствующие файлы в зарезервированный языковой каталог и сохранить логические ключи по правилам выше. Новая миграция SQLite для добавления перевода не требуется.

## Практика SQL

Локальные SQL-задачи хранятся отдельно от тестов и лабораторных:

```text
course-content/
└── practice/
    └── <collection>/
        └── <task>/
            ├── en/
            │   ├── practice.json
            │   ├── setup.sql
            │   └── solution.sql
            └── ru/
                ├── practice.json
                ├── setup.sql
                └── solution.sql
```

`setup.sql` создаёт изолированную SQLite-песочницу задания, `solution.sql` содержит эталонное решение, а `practice.json` описывает учебную часть и правила проверки.

Поддерживаемые поля `practice.json`:

- `category` — раздел практики;
- `type` — `write_query`, `fix_query` или `find_logical_error`;
- `comparison` — `ordered`, `unordered`, `scalar` или `row_count`;
- `difficulty` — `easy`, `medium` или `hard`;
- `starter_sql` — стартовый текст редактора;
- `hints` — последовательные подсказки;
- `solution_explanation` — объяснение эталонного решения;
- `rules` — ограничения решения (`require_keyword`, `forbid_keyword`, `forbid_select_star`);
- `assertions` — дополнительные проверки состояния песочницы и результата.

Доступные assertions:

```json
{"type": "result_equals_solution"}
{"type": "table_exists", "table": "users"}
{"type": "index_exists", "index": "idx_users_email"}
{"type": "scalar_equals", "sql": "SELECT COUNT(*) FROM users", "expected": "3"}
{"type": "row_count_equals", "sql": "SELECT * FROM users", "expected": 3}
```

Если `assertions` не заданы, автоматически применяется `result_equals_solution`.

SQLite используется только как локальный offline-движок. Формат задания и прикладной интерфейс `PracticeEngine` не привязаны к SQLite, чтобы позднее можно было добавить PostgreSQL-движок без изменения TUI и банка заданий.

## Практика SQL

Локальные SQL-задачи хранятся отдельно от тестов и лабораторных:

```text
course-content/
└── practice/
    └── <collection>/
        └── <task>/
            ├── en/
            │   ├── practice.json
            │   ├── setup.sql
            │   └── solution.sql
            └── ru/
                ├── practice.json
                ├── setup.sql
                └── solution.sql
```

`setup.sql` создаёт изолированную SQLite-песочницу задания, `solution.sql` содержит эталонное решение, а `practice.json` описывает учебную часть и правила проверки.

Поддерживаемые поля `practice.json`:

- `category` — раздел практики;
- `type` — `write_query`, `fix_query` или `find_logical_error`;
- `comparison` — `ordered`, `unordered`, `scalar` или `row_count`;
- `difficulty` — `easy`, `medium` или `hard`;
- `starter_sql` — стартовый текст редактора;
- `hints` — последовательные подсказки;
- `solution_explanation` — объяснение эталонного решения;
- `rules` — ограничения решения (`require_keyword`, `forbid_keyword`, `forbid_select_star`);
- `assertions` — дополнительные проверки состояния песочницы и результата.

Доступные assertions:

```json
{"type": "result_equals_solution"}
{"type": "table_exists", "table": "users"}
{"type": "index_exists", "index": "idx_users_email"}
{"type": "scalar_equals", "sql": "SELECT COUNT(*) FROM users", "expected": "3"}
{"type": "row_count_equals", "sql": "SELECT * FROM users", "expected": 3}
```

Если `assertions` не заданы, автоматически применяется `result_equals_solution`.

SQLite используется только как локальный offline-движок. Формат задания и прикладной интерфейс `PracticeEngine` не привязаны к SQLite, чтобы позднее можно было добавить PostgreSQL-движок без изменения TUI и банка заданий.

## Практика SQL

Локальные SQL-задачи хранятся отдельно от тестов и лабораторных:

```text
course-content/
└── practice/
    └── <collection>/
        └── <task>/
            ├── en/
            │   ├── practice.json
            │   ├── setup.sql
            │   └── solution.sql
            └── ru/
                ├── practice.json
                ├── setup.sql
                └── solution.sql
```

`setup.sql` создаёт изолированную SQLite-песочницу задания, `solution.sql` содержит эталонное решение, а `practice.json` описывает учебную часть и правила проверки.

Поддерживаемые поля `practice.json`:

- `category` — раздел практики;
- `type` — `write_query`, `fix_query` или `find_logical_error`;
- `comparison` — `ordered`, `unordered`, `scalar` или `row_count`;
- `difficulty` — `easy`, `medium` или `hard`;
- `starter_sql` — стартовый текст редактора;
- `hints` — последовательные подсказки;
- `solution_explanation` — объяснение эталонного решения;
- `rules` — ограничения решения (`require_keyword`, `forbid_keyword`, `forbid_select_star`);
- `assertions` — дополнительные проверки состояния песочницы и результата.

Доступные assertions:

```json
{"type": "result_equals_solution"}
{"type": "table_exists", "table": "users"}
{"type": "index_exists", "index": "idx_users_email"}
{"type": "scalar_equals", "sql": "SELECT COUNT(*) FROM users", "expected": "3"}
{"type": "row_count_equals", "sql": "SELECT * FROM users", "expected": 3}
```

Если `assertions` не заданы, автоматически применяется `result_equals_solution`.

SQLite используется только как локальный offline-движок. Формат задания и прикладной интерфейс `PracticeEngine` не привязаны к SQLite, чтобы позднее можно было добавить PostgreSQL-движок без изменения TUI и банка заданий.
